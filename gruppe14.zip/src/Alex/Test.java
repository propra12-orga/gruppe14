package Alex;

public class Test {
	public static void main(String[] args){
		gameplay.controls("left");
	}
}